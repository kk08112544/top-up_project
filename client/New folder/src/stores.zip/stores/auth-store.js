import { defineStore } from "pinia";
export const useAuthStore = defineStore("auth", {
  state: () => ({
    userList: [
      {
        name: "admin",
        username: "admin@gmail.com",
        password: "qwe123",
        role: "admin",
      },
      {
        name: "suwara001",
        username: "suwara@gmail.com",
        password: "suwara001",
        role: "user",
      },
    ],
    me: {},
  }),
  actions: {
    onSetUser(payload) {
      this.userList.push(payload);
    },
    onLogIn(payload) {
      this.me = payload;
    },
    onLogOut() {
      this.me = {};
    },
  },
  persist: {
    enabled: true,
  },
});
